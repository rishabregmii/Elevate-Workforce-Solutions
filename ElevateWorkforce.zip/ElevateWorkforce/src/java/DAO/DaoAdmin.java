package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import dbHelper.MyConnect;
import model.Admin;
import java.sql.*;


public class DaoAdmin {
    
    // Update student record
    public static int doSave(Admin a) {
        int status = 0;
        Connection conn = MyConnect.connectDatab();
        
        String sql = "UPDATE admin SET name=?, address=?, username=?, password=? WHERE id=?";
        try {  
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, a.getName());
            pst.setString(2, a.getAddress());
            pst.setString(3, a.getUsername());
            pst.setString(4, a.getPassword());
            pst.setInt(5, a.getId());
            
            System.out.println("Testing doSave...");
            status = pst.executeUpdate();
        } catch(Exception e) {
            e.printStackTrace();
        }  
        return status;
    }
    
    // Another update method (same as doSave)
    public static int doUpdat(Admin a) {
        int status = 0;
        Connection conn = MyConnect.connectDatab();
        
        String sql = "UPDATE admin SET name=?, address=?, username=?, password=? WHERE id=?";
        try {  
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, a.getName());
            pst.setString(2, a.getAddress());
            pst.setString(3, a.getUsername());
            pst.setString(4, a.getPassword());
            pst.setInt(5, a.getId());
            
            System.out.println("Testing doUpdat...");
            status = pst.executeUpdate();
        } catch(Exception e) {
            e.printStackTrace();
        }  
        return status;
    }
    
    
   public static int doDel(Admin a)
    {
    int status=0;
       Connection conn = MyConnect.connectDatab();
        try
        {
    
        String sql="delete from admin where id=?";
        PreparedStatement pst=conn.prepareStatement(sql);
        pst.setInt(1,a.getId());
        status=pst.executeUpdate();         
        }
        catch(Exception e)
        {            
        }
       
        
        return status;   
    }
    
 public static int doLogin(Admin a) {
    int status = 0;
    Connection conn = MyConnect.connectDatab();

    try {
        String sql = "SELECT * FROM admin WHERE username=? AND password=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, a.getUsername());
        pst.setString(2, a.getPassword());

        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
        
            status = 1; // Found matching record → login success
        
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return status;
}

}
