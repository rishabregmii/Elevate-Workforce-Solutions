package DAO;

import dbHelper.MyConnect;
import model.Application;
import java.sql.*;
import java.util.*;

public class DaoApplication {

    public static List<Application> getApplicationsByUser(int userId) {
        List<Application> list = new ArrayList<>();
        try {
            Connection conn = MyConnect.connectDatab();
            String sql = "SELECT a.*, j.title AS jobtitle, j.company AS company " +
                         "FROM applications a " +
                         "JOIN jobs j ON a.job_id = j.id " +
                         "WHERE a.user_id = ? ORDER BY a.applied_date DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Application app = new Application();
                app.setId(rs.getInt("id"));
                app.setUserID(rs.getInt("user_id"));
                app.setJobID(rs.getInt("job_id"));
                app.setJobtitle(rs.getString("jobtitle"));
                app.setCompany(rs.getString("company"));
                app.setApplieddate(rs.getString("applied_date"));
                app.setStatus(rs.getString("status"));
                list.add(app);
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public static int addApplication(Application app) {
    int status = 0;
    try (Connection conn = MyConnect.connectDatab()) {

        String sql = "INSERT INTO applications (user_id, job_id, applied_date, status) VALUES (?, ?, NOW(), ?)";
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setInt(1, app.getUserID());
        ps.setInt(2, app.getJobID());
        ps.setString(3, app.getStatus());

        status = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
    return status;
}


}
