package DAO;

import java.sql.*;
import dbHelper.MyConnect;
import model.User;

public class DaoUser {

    // ✅ Register a new user
    public static int registerUser(User u) {
        int status = 0;
        String sql = "INSERT INTO user (name, email, username, password, phone) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = MyConnect.connectDatab();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, u.getName());
            pst.setString(2, u.getEmail());
            pst.setString(3, u.getUsername());
            pst.setString(4, u.getPassword());
            pst.setString(5, u.getPhone());

            status = pst.executeUpdate();
            System.out.println("User registered successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // ✅ Update user profile
    // ✅ Update user profile
public static int updateUser(User u) {
    int status = 0;
    String sql = "UPDATE user SET name=?, email=?, username=?, password=?, phone=?, resume=? WHERE id=?";
    try (Connection conn = MyConnect.connectDatab();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, u.getName());
        pst.setString(2, u.getEmail());
        pst.setString(3, u.getUsername());
        pst.setString(4, u.getPassword());
        pst.setString(5, u.getPhone());
        pst.setString(6, u.getResume());
        pst.setInt(7, u.getId());

        status = pst.executeUpdate();
        System.out.println("User updated successfully. Rows affected: " + status);

    } catch (Exception e) {
        e.printStackTrace();
    }
    return status;
}

    // ✅ Delete user
    public static int deleteUser(int id) {
        int status = 0;
        String sql = "DELETE FROM user WHERE id=?";
        try (Connection conn = MyConnect.connectDatab();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, id);
            status = pst.executeUpdate();
            System.out.println("User deleted successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // ✅ Login and return User details (instead of boolean)
    public static User doLogin(String username, String password) {
        User u = null;
        String sql = "SELECT * FROM user WHERE username=? AND password=?";
        try (Connection conn = MyConnect.connectDatab();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, username);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setEmail(rs.getString("email"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setPhone(rs.getString("phone"));
                u.setResume(rs.getString("resume"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return u;
    }

    // ✅ Fetch user by username
    public static User getUserByUsername(String username) {
        User u = null;
        String sql = "SELECT * FROM user WHERE username=?";
        try (Connection conn = MyConnect.connectDatab();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setEmail(rs.getString("email"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setPhone(rs.getString("phone"));
                u.setResume(rs.getString("resume"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return u;
    }
}
