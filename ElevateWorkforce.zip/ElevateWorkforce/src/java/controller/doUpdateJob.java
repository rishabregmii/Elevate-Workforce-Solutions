package controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Job;
import DAO.DaoJobs;
import dbHelper.MyConnect;
import java.sql.*;

public class doUpdateJob extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
              int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String company = request.getParameter("company");
        String location = request.getParameter("location");
        String salary = request.getParameter("salary");
        String description = request.getParameter("description");
        String type = request.getParameter("type");

        try {
            
            
            Connection conn = MyConnect.connectDatab();
            String sql = "UPDATE jobs SET title=?, company=?, location=?, salary=?, description=?, type=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, company);
            ps.setString(3, location);
            ps.setString(4, salary);
            ps.setString(5, description);
            ps.setString(6, type);
            ps.setInt(7, id);

            int result = ps.executeUpdate();
            ps.close();
            conn.close();

            if (result > 0)
                response.sendRedirect(request.getContextPath() + "/admin/dashboard.jsp");
            else
                response.sendRedirect(request.getContextPath() + "/admin/dashboard.jsp?error=updateFailed");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("../admin/dashboard.jsp?error=" + e.getMessage());
        }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
