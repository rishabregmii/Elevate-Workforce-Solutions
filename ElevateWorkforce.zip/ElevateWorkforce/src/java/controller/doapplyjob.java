package controller;

import DAO.DaoApplication;
import model.Application;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/doApplyJob")
public class doapplyjob extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int userId = Integer.parseInt(request.getParameter("userId"));
        int jobId = Integer.parseInt(request.getParameter("jobId"));

        Application app = new Application();
        app.setUserID(userId);
        app.setJobID(jobId);
        app.setStatus("Pending");

        int status = DaoApplication.addApplication(app);

        if (status > 0) {
            response.sendRedirect("applications.jsp?msg=Application submitted successfully!");
        } else {
            response.sendRedirect("findajob.jsp");
        }
    }
}
