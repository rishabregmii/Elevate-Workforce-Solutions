/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import DAO.DaoUser;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.User;

public class doUserRegister extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");

        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setUsername(username);
        u.setPassword(password);
        u.setPhone(phone);

        int status = DaoUser.registerUser(u);

        if (status > 0) {
            response.sendRedirect("login.jsp?msg=Registration successful! Please login.");
        } else {
            response.sendRedirect("register.jsp?msg=Registration failed. Try again.");
        }
    }
}

