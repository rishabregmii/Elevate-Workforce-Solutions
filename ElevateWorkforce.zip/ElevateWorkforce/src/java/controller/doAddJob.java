package controller;

import DAO.DaoJobs;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import model.Job;

@WebServlet("/controller/doAddJob")
public class doAddJob extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form data
        String title = request.getParameter("title");
        String company = request.getParameter("company");
        String location = request.getParameter("location");
        String salaryStr = request.getParameter("salary");
        String description = request.getParameter("description");
        String type = request.getParameter("type");

        double salary = 0;
        if (salaryStr != null && !salaryStr.isEmpty()) {
            salary = Double.parseDouble(salaryStr);
        }

        // Create Job object
        Job j = new Job();
        j.setTitle(title);
        j.setCompany(company);
        j.setLocation(location);
        j.setSalary(salary);
        j.setDescription(description);
        j.setType(type);

        // Save to database
        int result = DaoJobs.addJob(j);

        if (result > 0) {
            response.sendRedirect("../admin/dashboard.jsp"); // success redirect
        } else {
            response.sendRedirect("../admin/addnewjob.jsp?error=1"); // error case
        }
    }
}
