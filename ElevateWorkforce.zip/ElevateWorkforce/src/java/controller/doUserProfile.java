package controller;

import DAO.DaoUser;
import model.User;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;

@MultipartConfig
public class doUserProfile extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");

        Part filePart = request.getPart("resume");
        String fileName = "";
        String uploadPath = request.getServletContext().getRealPath("") + "uploads";

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        if (filePart != null && filePart.getSize() > 0) {
            fileName = filePart.getSubmittedFileName();
            filePart.write(uploadPath + File.separator + fileName);
        }

        User u = new User();
        u.setId(id);
        u.setName(name);
        u.setEmail(email);
        u.setUsername(username);
        u.setPassword(password);
        u.setPhone(phone);
        if (!fileName.isEmpty()) {
            u.setResume("uploads/" + fileName);
        } else {
            // Keep existing resume if not uploaded
            User existing = DaoUser.getUserByUsername(username);
            u.setResume(existing.getResume());
        }

        int status = DaoUser.updateUser(u);

        if (status > 0) {
            response.sendRedirect("profile.jsp?msg=Profile updated successfully!");
        } else {
            response.sendRedirect("profile.jsp?msg=Update failed. Try again.");
        }
    }
}
