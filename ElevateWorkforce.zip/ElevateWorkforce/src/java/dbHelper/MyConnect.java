/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbHelper;
import java.sql.*;
public class MyConnect {
    public static Connection connectDatab()
    {
        try
        {
     Class.forName("com.mysql.cj.jdbc.Driver");
     
     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/jobsportal","root","");
            System.out.println("Connected to  the database");
return conn;
        }
        catch(Exception e)
            
        {
            System.out.println(e.getMessage());
        }
        return null;
    
}
    
}
